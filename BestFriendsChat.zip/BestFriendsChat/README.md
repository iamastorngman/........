# BestFriends Chat

A private, Instagram-inspired group chat built with Python (Flask), HTML, CSS, and JavaScript.

## Features
- Password-protected entry screen
- Choose a chat display name
- Shared group chat for everyone using the same server
- Messages stored in a local SQLite database
- Near-live message updates (polling every 1.8 seconds)
- Responsive layout for desktop and mobile

## Run on Windows

1. Install Python 3.10 or newer.
2. Open Command Prompt in this folder.
3. Install the dependency:

   ```bat
   py -m pip install -r requirements.txt
   ```

4. Start the server:

   ```bat
   py app.py
   ```

5. Open this address in your browser:

   `http://127.0.0.1:5000`

Room password: `wearebestfriends`

## Let friends on the same Wi-Fi join

- Keep the server running on your PC.
- Find your PC's local IPv4 address by running `ipconfig` in Command Prompt.
- On another device connected to the same Wi-Fi, open `http://YOUR-PC-IP:5000`.
- If Windows Firewall asks, allow Python on your private network.

## Important security notes before putting it on the public internet

The requested room password is configured as the default. Anyone who knows it can enter the same room. For a public deployment, set a strong `CHAT_PASSWORD` and a random `SECRET_KEY` as environment variables, use HTTPS, and add per-user accounts/rate limiting. Do not expose the development server directly to the public internet.

Example PowerShell setup:

```powershell
$env:CHAT_PASSWORD = "replace-with-a-long-private-password"
$env:SECRET_KEY = "replace-with-a-long-random-secret"
py app.py
```

Messages are stored in `chat.db` beside `app.py`. Back up that file if you want to keep chat history.
